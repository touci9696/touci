<p align="center">
<a><img title="Built With Love" src="https://forthebadge.com/images/badges/built-with-love.svg" ></a>

# <p align="center">Termux-Megapackage
![termux-meg](https://user-images.githubusercontent.com/68908732/88683463-75400300-d111-11ea-967c-9b80e94f36ab.jpg)
<p align="center">
      All In One Package For Termux
<p align="center">
<a href="https://github.com/Hackeralok119"><img title="Open Source" src="https://img.shields.io/badge/Open%20Source-%E2%99%A5-red" ></a>
  <a href="https://paypal.me/alokhacker"><img title="Donate" src="https://img.shields.io/badge/Donate-PayPal-blue" ></a>
  <a href="https://github.com/Hackeralok119/Termux-Megapackage"><img title="GitHub version" src="https://d25lcipzij17d.cloudfront.net/badge.svg?id=gh&type=6&v=1.0.0&x2=0" ></a>
<a href="https://github.com/Bhaviktutorials"><img title="GitHub version" src="https://img.shields.io/github/license/Bhaviktutorials/Termux-Megapackage" ></a>
  <a href="https://youtube.com/channel/UC81152-HcsSx9MAyGVQ_rFg"><img alt="Youtube" src="https://img.shields.io/badge/Youtube-Master Of Technology-green"/></a>
  <a href="https://instagram.com/Hackeralok2.0"><img alt="Instagram" src="https://img.shields.io/badge/Instagram-Hackeralok2.0-Blue"/></a>
</p>

###### <p align="center">*This is official repository maintained by us*
###### <p align="center"> *[**@Hacker Alok **](https://www.instagram.com/Hackeralok2.0/) ❤️*
###### <p align="center"> *You can check [YouTube](https://youtube.com/channel/UCVH42IFhbGAeJDtC3TJSfzA)✌*
---
### What is Megapackage??
Its Hard to Install Every Huge Tool like Metasploit, Kali Nethunter Rootless and Other Neccesarry Tools Together in Click. So We Thought to Build a Package where you Guys Can Install all this Just in Click But thats not only Feature of this Megapackage. We guys also have include a GodeMode(Termux-Black) Which Slightly reduce the error of unlocated package because of little change in sources.list Which make this Termux-Megapackage as Good as Heaven for Termux User.

 ### Installation Termux-Megapackage
 * `Commands` for termux
```
$ termux-setup-storage

$ pkg update && pkg upgrade && pkg install git -y

$ git clone https://github.com/Hackeralok119/Kali-Megapackage

$ ls

$ cd Kali-Megapackage

$ ls

$ chmod +x *

$ ./install.sh

$ m-pkg
```
#### For Video Tutorial:-
[YouTube](https://www.youtube.com/channel/UCFbU5tKMUI51CEXKZhTCNRg)


 #### You can download the required package as per your need :)
 (Just Open Issue As A Package Request)
 ### List Of Available Packages
 1. *_zphisher_*
 2. *_HiddenEye_*
 3. *_shark_*
 4. *_T-Remix_*
 5. *_GodMode_*
 6. *_WireShark_*
 7. *_Termux-Keys_*
 8. *_metasploit-framework_*
 9. *_Kali-nethunter-termux_*
 10. *_Optical-Framework_*
 11. *_ubuntu-in-termux_*
 12. *_ghost_*
 13. *_TBomb_*
 14. *_WishFish_*
 15. *_Impulse_*
 16. *_lockphish_*
 17. *_RED_HAWK_*
 18. *_termux-omz_*
 19. *_cupp_*
 20. *_Fakeroot_*
 ### Screenshots
 After Installing _Termux-Megapackage_:-
![Screenshot_2020-10-31-14-08-25-297_com termux](https://user-images.githubusercontent.com/70144305/97775081-989ca300-1b83-11eb-87ce-a99158e5d176.jpg)
![Screenshot_2020-10-31-14-20-07-868_com termux](https://user-images.githubusercontent.com/70144305/97775133-4445f300-1b84-11eb-9322-f64711a0919c.jpg)
***
####  If Like This Tool Dont Donate Just a Subscribe will be Awseome!!! 
## Development by :-

## Developer / Author: Alok / [Hacker alok](https://github.com/Hackeralok119/)

## Company: [Hacker alok](https://www.youtube.com/channel/UCFbU5tKMUI51CEXKZhTCNRg)


## To Know about Ethical Hacking , Android And Kali Linux Do Follow Us:

<a href="https://github.com/Hackeralok119/"><img src="https://user-images.githubusercontent.com/64035221/96459220-834c7e00-123f-11eb-8417-534058a7ba62.png" alt="GitHub" width="110" height="110">
<a href="https://youtube.com/channel/UC81152-HcsSx9MAyGVQ_rFg"><img src="https://user-images.githubusercontent.com/64035221/96456596-4f238e00-123c-11eb-821e-85e9aaa3faec.png" alt="YouTube" width="110" height="110">
<a href="https://t.me/Anonymoushacksz"><img src="https://user-images.githubusercontent.com/64035221/96461243-c576bf00-1241-11eb-8fdf-139b4859bfb0.png" alt="Telegram" width="80" height="80">
<a href="https://www.instagram.com/Hackeralok2.0/"><img src="https://user-images.githubusercontent.com/64035221/96461629-3d44e980-1242-11eb-8691-46dd14355085.png" alt="Instagram" width="90" height="90">
